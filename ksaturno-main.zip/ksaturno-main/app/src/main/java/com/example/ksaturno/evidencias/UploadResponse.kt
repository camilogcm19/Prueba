package com.example.ksaturno.evidencias

import com.google.gson.annotations.SerializedName

data class UploadResponse(
    @SerializedName("success") val success: Boolean,
    @SerializedName("message") val message: String,
    @SerializedName("path") val path: String? // La ruta en el servidor
)
