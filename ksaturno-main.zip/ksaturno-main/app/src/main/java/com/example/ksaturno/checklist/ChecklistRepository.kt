package com.example.ksaturno.checklist

import com.example.ksaturno.ApiService
import com.example.ksaturno.ApiResponse
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import retrofit2.HttpException
import java.io.IOException

class ChecklistRepository(private val apiService: ApiService) {

    /**
     * Fetches the master list of all possible checklist items.
     */
    suspend fun getMasterChecklistItems(): List<ChecklistItem> {
        return withContext(Dispatchers.IO) {
            try {
                val response = apiService.getChecklistItems()
                if (response.isSuccessful) {
                    response.body() ?: emptyList()
                } else {
                    throw IOException("Error fetching master checklist: ${response.code()}")
                }
            } catch (e: Exception) {
                // Re-throw so the ViewModel can catch it and display an error
                throw IOException("Failed to load checklist items: ${e.message}", e)
            }
        }
    }

    suspend fun createChecklistItem(request: CreateChecklistItemRequest): ApiResponse {
        return withContext(Dispatchers.IO) {
            val response = apiService.createChecklistItem(request)
            if (response.isSuccessful && response.body() != null) response.body()!! else ApiResponse(false, "Error: ${response.code()}")
        }
    }

    suspend fun updateChecklistItem(item: ChecklistItem): ApiResponse {
        return withContext(Dispatchers.IO) {
            val response = apiService.updateChecklistItem(item.id, item)
            if (response.isSuccessful && response.body() != null) response.body()!! else ApiResponse(false, "Error: ${response.code()}")
        }
    }

    suspend fun deleteChecklistItem(itemId: Int): ApiResponse {
        return withContext(Dispatchers.IO) {
            val response = apiService.deleteChecklistItem(ChecklistItemIdBody(itemId))
            if (response.isSuccessful && response.body() != null) response.body()!! else ApiResponse(false, "Error: ${response.code()}")
        }
    }

    /**
     * Saves the state of a specific checklist item (checked/unchecked) for a specific installation.
     */
    suspend fun saveChecklistItemState(request: CreateListaVerificacionRequest): ApiResponse {
        return withContext(Dispatchers.IO) {
            try {
                val response = apiService.saveChecklistItem(request)
                
                if (response.isSuccessful) {
                    return@withContext response.body() ?: ApiResponse(true, "Estado guardado (respuesta vacía)", null)
                }
                
                ApiResponse(false, "Error de red: ${response.code()}", null)

            } catch (e: HttpException) {
                ApiResponse(false, "Error HTTP: ${e.code()} ${e.message()}", null)
            } catch (e: IOException) {
                ApiResponse(false, "Error de red: ${e.message}", null)
            } catch (e: Exception) {
                ApiResponse(false, "Excepción: ${e.message}", null)
            }
        }
    }
}
