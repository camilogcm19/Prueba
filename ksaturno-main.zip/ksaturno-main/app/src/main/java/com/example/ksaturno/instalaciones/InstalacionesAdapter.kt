package com.example.ksaturno.instalaciones

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.ksaturno.R
import java.text.SimpleDateFormat
import java.util.Locale

class InstalacionesAdapter(
    private var instalaciones: List<InstalacionDisplay>,
    private val userRole: String, // Pass user role to adapter
    private val onEditClick: (InstalacionDisplay) -> Unit,
    private val onDeleteClick: (InstalacionDisplay) -> Unit,
    private val onGenerateInvoiceClick: (InstalacionDisplay) -> Unit
) : RecyclerView.Adapter<InstalacionesAdapter.InstalacionViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): InstalacionViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_instalacion, parent, false)
        return InstalacionViewHolder(view)
    }

    override fun onBindViewHolder(holder: InstalacionViewHolder, position: Int) {
        val instalacion = instalaciones[position]
        // Pass role to the ViewHolder to control UI visibility
        holder.bind(instalacion, userRole, onEditClick, onDeleteClick, onGenerateInvoiceClick)
    }

    override fun getItemCount(): Int = instalaciones.size

    fun updateData(newInstalaciones: List<InstalacionDisplay>) {
        instalaciones = newInstalaciones
        notifyDataSetChanged()
    }

    class InstalacionViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val idTextView: TextView = itemView.findViewById(R.id.tv_instalacion_id)
        private val unidadTextView: TextView = itemView.findViewById(R.id.tv_unidad_nombre)
        private val tecnicoTextView: TextView = itemView.findViewById(R.id.tv_tecnico_nombre)
        private val fechaTextView: TextView = itemView.findViewById(R.id.tv_fecha_instalacion)
        private val estadoTextView: TextView = itemView.findViewById(R.id.tv_instalacion_estado)
        private val editButton: ImageView = itemView.findViewById(R.id.btn_edit_instalacion)
        private val deleteButton: ImageView = itemView.findViewById(R.id.btn_delete_instalacion)
        private val invoiceButton: ImageView = itemView.findViewById(R.id.btn_generate_invoice)

        fun bind(
            instalacion: InstalacionDisplay,
            userRole: String,
            onEditClick: (InstalacionDisplay) -> Unit,
            onDeleteClick: (InstalacionDisplay) -> Unit,
            onGenerateInvoiceClick: (InstalacionDisplay) -> Unit
        ) {
            idTextView.text = "Instalacion ID: ${instalacion.idInstalacion}"
            unidadTextView.text = "Unidad: ${instalacion.nombreUnidad}"
            tecnicoTextView.text = "Técnico: ${instalacion.nombreTecnico}"
            
            fechaTextView.text = "Fecha: ${instalacion.fechaInstalacion ?: "N/A"}"
            estadoTextView.text = "Estado: ${instalacion.estado ?: "N/A"}"
            
            // --- LOGIC FOR BUTTON VISIBILITY ---
            val isAdmin = userRole.equals("admin", ignoreCase = true)

            deleteButton.visibility = if (isAdmin) View.VISIBLE else View.GONE
            invoiceButton.visibility = if (isAdmin) View.VISIBLE else View.GONE

            // Click listeners are only needed for visible buttons
            if (isAdmin) {
                deleteButton.setOnClickListener { onDeleteClick(instalacion) }
                invoiceButton.setOnClickListener { onGenerateInvoiceClick(instalacion) }
            }

            // Everyone can edit (for now)
            editButton.setOnClickListener { onEditClick(instalacion) }
        }
    }
}
