package com.example.ksaturno.notifications

import com.google.gson.annotations.SerializedName

data class UpdateFcmTokenRequest(
    @SerializedName("id_usuario") val userId: Int, // O el identificador que uses para el usuario
    @SerializedName("fcm_token") val fcmToken: String
)
