package com.example.ksaturno.home

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.ksaturno.RetrofitClient
import com.example.ksaturno.instalaciones.InstalacionDisplay
import com.example.ksaturno.instalaciones.InstalacionesRepository
import kotlinx.coroutines.launch

class HomeViewModel : ViewModel() {

    private val repository = HomeRepository()
    private val instalacionesRepository = InstalacionesRepository(RetrofitClient.instance)

    private val _renewalAlerts = MutableLiveData<List<RenewalAlert>>()
    val renewalAlerts: LiveData<List<RenewalAlert>> = _renewalAlerts
    
    private val _technicianTasks = MutableLiveData<List<InstalacionDisplay>>()
    val technicianTasks: LiveData<List<InstalacionDisplay>> = _technicianTasks

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    private val _totalRenewals = MutableLiveData<Int>()
    val totalRenewals: LiveData<Int> = _totalRenewals

    private val _totalAmount = MutableLiveData<Double>()
    val totalAmount: LiveData<Double> = _totalAmount

    // Remove init block to load data manually with context
    // init {
    //     loadDashboardData()
    // }

    fun loadDashboardData(role: String = "admin", userId: Int = -1) {
        _isLoading.value = true
        viewModelScope.launch {
            try {
                if (role.equals("tecnico", ignoreCase = true) && userId != -1) {
                    // Load technician specific data
                    val tasks = instalacionesRepository.getInstalacionesPendientesTecnico(userId)
                    _technicianTasks.postValue(tasks)
                    
                    // Technicians might not need renewal alerts, or maybe yes?
                    // For now, we clear them or keep them empty
                    _renewalAlerts.postValue(emptyList())
                    _totalRenewals.postValue(tasks.size) // Reuse this counter for tasks count
                    _totalAmount.postValue(0.0) 
                    
                } else {
                    // Load standard dashboard data (Admin/Client)
                    val alerts = repository.getRenewalAlerts()
                    _renewalAlerts.postValue(alerts)
                    _totalRenewals.postValue(alerts.size)
                    _totalAmount.postValue(alerts.sumOf { it.monto })
                    _technicianTasks.postValue(emptyList())
                }
            } catch (e: Exception) {
                // Handle error
                e.printStackTrace()
            } finally {
                _isLoading.postValue(false)
            }
        }
    }
}
