package com.example.ksaturno.instalaciones

import com.google.gson.annotations.SerializedName
import java.util.Date

/**
 * A data class specifically designed for display purposes in the UI.
 * It holds all the necessary information, already resolved, to show in the installation list.
 */
data class InstalacionDisplay(
    @SerializedName("id_instalacion") val idInstalacion: Int,
    @SerializedName("fecha_instalacion") val fechaInstalacion: String?, 
    @SerializedName("estado") val estado: String?,
    @SerializedName("componentes") val componentes: String?,
    @SerializedName("comentarios") val comentarios: String?,
    @SerializedName("nombreServicio") val nombreServicio: String,
    @SerializedName("nombreUnidad") val nombreUnidad: String,
    @SerializedName("nombreTecnico") val nombreTecnico: String
)
