package com.example.ksaturno

import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.PopupMenu
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.navigation.NavController
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.NavigationUI
import androidx.navigation.ui.setupActionBarWithNavController
import com.example.ksaturno.databinding.ActivityMainBinding
import com.example.ksaturno.notifications.FcmTokenManager
import android.Manifest

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var navController: NavController

    // Register the permissions callback
    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted: Boolean ->
        if (!isGranted) {
            Toast.makeText(this, "Las notificaciones están desactivadas", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        
        askNotificationPermission()
        
        // Get Session Data
        val sharedPref = getSharedPreferences("UserSession", MODE_PRIVATE)
        val userId = sharedPref.getInt("USER_ID", -1)
        val userRole = sharedPref.getString("USER_ROLE", "admin") ?: "admin"
        
        if (userId != -1) {
            FcmTokenManager.updateTokenOnServer(this, userId)
        }

        val navHostFragment = supportFragmentManager
            .findFragmentById(R.id.nav_host_fragment) as NavHostFragment
        navController = navHostFragment.navController

        val appBarConfiguration = AppBarConfiguration(setOf(
            R.id.navigation_home, R.id.navigation_clients, R.id.navigation_operations, 
            R.id.navigation_finance, R.id.navigation_more))
        setupActionBarWithNavController(navController, appBarConfiguration)

        // Configure Menu based on Role
        setupMenuByRole(userRole)

        binding.bottomNavigation.setOnItemSelectedListener { item ->
            handleBottomNavigation(item)
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (navController.currentDestination?.id == navController.graph.startDestinationId) {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("Confirmar Salida")
                        .setMessage("¿Estás seguro de que deseas cerrar la aplicación?")
                        .setPositiveButton("Sí") { _, _ -> finish() }
                        .setNegativeButton("No", null)
                        .show()
                } else {
                    navController.navigateUp()
                }
            }
        })
    }

    private fun setupMenuByRole(role: String) {
        val menu = binding.bottomNavigation.menu

        // First, hide everything except the home button
        menu.findItem(R.id.navigation_clients).isVisible = false
        menu.findItem(R.id.navigation_operations).isVisible = false
        menu.findItem(R.id.navigation_finance).isVisible = false
        menu.findItem(R.id.navigation_more).isVisible = false

        // Now, show items based on the user's role
        when (role.lowercase()) {
            "admin" -> {
                // Admin sees everything
                menu.findItem(R.id.navigation_clients).isVisible = true
                menu.findItem(R.id.navigation_operations).isVisible = true
                menu.findItem(R.id.navigation_finance).isVisible = true
                menu.findItem(R.id.navigation_more).isVisible = true
            }
            "tecnico" -> {
                // Technician only sees Operations
                menu.findItem(R.id.navigation_operations).isVisible = true
            }
            "cliente" -> {
                // Client only sees Finance
                menu.findItem(R.id.navigation_finance).isVisible = true
            }
        }
    }

    private fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) ==
                PackageManager.PERMISSION_GRANTED
            ) {
                // Permission granted
            } else if (shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS)) {
                 AlertDialog.Builder(this)
                    .setTitle("Permiso de Notificaciones")
                    .setMessage("Para avisarte sobre vencimientos y actualizaciones, necesitamos permiso para enviarte notificaciones.")
                    .setPositiveButton("OK") { _, _ ->
                        requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    }
                    .setNegativeButton("No gracias", null)
                    .show()
            } else {
                requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    private fun handleBottomNavigation(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.navigation_operations, R.id.navigation_finance, R.id.navigation_more -> {
                val anchorView = binding.bottomNavigation.findViewById<View>(item.itemId)
                val menuRes = when (item.itemId) {
                    R.id.navigation_operations -> R.menu.operations_submenu
                    R.id.navigation_finance -> R.menu.finance_submenu
                    else -> R.menu.more_submenu
                }
                showPopupMenu(anchorView, menuRes)
                return false
            }
            else -> {
                return NavigationUI.onNavDestinationSelected(item, navController)
            }
        }
    }

    private fun showPopupMenu(anchorView: View, menuRes: Int) {
        val popupMenu = PopupMenu(this, anchorView)
        popupMenu.menuInflater.inflate(menuRes, popupMenu.menu)
        popupMenu.setOnMenuItemClickListener { menuItem ->
            // Since we have matching IDs in nav_graph for all menu items (including evidence_upload),
            // we can just let NavigationUI handle it.
            val navigated = NavigationUI.onNavDestinationSelected(menuItem, navController)
            if (!navigated) {
                // Fallback or debug
                // Toast.makeText(this, "Navegación fallida: ${menuItem.title}", Toast.LENGTH_SHORT).show()
            }
            true
        }
        popupMenu.show()
    }

    override fun onSupportNavigateUp(): Boolean {
        return navController.navigateUp() || super.onSupportNavigateUp()
    }
}
