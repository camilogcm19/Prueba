package com.example.ksaturno.instalaciones

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.ksaturno.R
import com.example.ksaturno.checklist.CompletedChecklistItem
import java.io.File
import java.io.FileOutputStream

class InstallationEvidenceFragment : Fragment(), InstallationEvidenceAdapter.EvidenceItemListener {

    private lateinit var viewModel: InstallationEvidenceViewModel
    private lateinit var adapter: InstallationEvidenceAdapter
    private val args: InstallationEvidenceFragmentArgs by navArgs()

    private var latestTmpUri: Uri? = null
    private var latestTmpFile: File? = null // Keep a reference to the actual file
    private var currentChecklistItem: CompletedChecklistItem? = null

    // Launcher for taking a picture
    private val takePictureLauncher = registerForActivityResult(ActivityResultContracts.TakePicture()) { isSuccess ->
        if (isSuccess) {
            // Use the File object we created, not the Uri
            latestTmpFile?.let { file ->
                currentChecklistItem?.let {
                    viewModel.saveEvidence(it.idListaVerificacion, file, "Descripción de la foto")
                }
            }
        }
    }

    // Launcher for picking an image from the gallery
    private val pickGalleryImageLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let {
            // The URI from the gallery is a 'content://' URI. We need to copy it to a local file
            // that our app can access and upload.
            val tempFile = File.createTempFile("gallery_evidence_", ".png", requireContext().cacheDir)
            val inputStream = requireContext().contentResolver.openInputStream(uri)
            val outputStream = FileOutputStream(tempFile)
            inputStream?.copyTo(outputStream)

            currentChecklistItem?.let {
                viewModel.saveEvidence(it.idListaVerificacion, tempFile, "Evidencia de galería")
            }
        }
    }

    // Launcher for requesting camera permission
    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted: Boolean ->
        if (isGranted) {
            // Permission granted, launch the camera now
            launchCamera()
        } else {
            Toast.makeText(requireContext(), "El permiso de la cámara es necesario para tomar fotos.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_installation_evidence, container, false)
        
        val installationId = args.installationId
        val factory = InstallationEvidenceViewModelFactory(installationId)
        viewModel = ViewModelProvider(this, factory).get(InstallationEvidenceViewModel::class.java)

        val recyclerView: RecyclerView = view.findViewById(R.id.recycler_view_evidence)
        adapter = InstallationEvidenceAdapter(emptyList(), this)
        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        recyclerView.adapter = adapter

        setupObservers()

        view.findViewById<Button>(R.id.button_finish_installation).setOnClickListener {
            findNavController().popBackStack(R.id.new_installation, false)
        }

        return view
    }

    private fun setupObservers() {
        viewModel.evidencePendingItems.observe(viewLifecycleOwner) {
            adapter.updateItems(it)
        }
        
        viewModel.error.observe(viewLifecycleOwner) { errorMessage ->
            if (!errorMessage.isNullOrEmpty()) {
                AlertDialog.Builder(requireContext())
                    .setTitle("Error")
                    .setMessage(errorMessage)
                    .setPositiveButton("OK", null)
                    .show()
            }
        }
        
        viewModel.saveSuccess.observe(viewLifecycleOwner) {
            if (it) {
                Toast.makeText(requireContext(), "Evidencia guardada correctamente", Toast.LENGTH_SHORT).show()
                viewModel.onSaveHandled()
                // Refresh the list to remove the completed item
                viewModel.fetchEvidencePendingItems() 
            }
        }
    }

    override fun onTakePhotoClick(item: CompletedChecklistItem) {
        currentChecklistItem = item
        
        // Check for camera permission before launching
        when {
            ContextCompat.checkSelfPermission(
                requireContext(),
                Manifest.permission.CAMERA
            ) == PackageManager.PERMISSION_GRANTED -> {
                // Permission is already granted, launch camera
                launchCamera()
            }
            shouldShowRequestPermissionRationale(Manifest.permission.CAMERA) -> {
                 AlertDialog.Builder(requireContext())
                    .setTitle("Permiso Requerido")
                    .setMessage("Se necesita acceso a la cámara para tomar fotos de evidencia.")
                    .setPositiveButton("OK") { _, _ ->
                        requestPermissionLauncher.launch(Manifest.permission.CAMERA)
                    }
                    .setNegativeButton("Cancelar", null)
                    .show()
            }
            else -> {
                // Directly request the permission
                requestPermissionLauncher.launch(Manifest.permission.CAMERA)
            }
        }
    }

    // NEW: Handle click on the gallery icon
    override fun onSelectGalleryClick(item: CompletedChecklistItem) {
        currentChecklistItem = item
        // Launch the gallery picker
        pickGalleryImageLauncher.launch("image/*")
    }

    private fun launchCamera() {
        // Save the file reference
        latestTmpFile = File.createTempFile("evidence_", ".png", requireContext().cacheDir).apply {
            createNewFile()
            deleteOnExit()
        }

        // Get a content URI for the file using a FileProvider
        latestTmpFile?.let { file ->
            latestTmpUri = FileProvider.getUriForFile(
                requireContext(),
                "${requireContext().packageName}.provider",
                file
            )
        }

        takePictureLauncher.launch(latestTmpUri)
    }
}