package com.example.ksaturno

import com.google.gson.annotations.SerializedName

data class LoginResponse(
    @SerializedName("success")
    val success: Boolean,

    @SerializedName("user")
    val user: User?,

    @SerializedName("message")
    val message: String?
)

data class User(
    @SerializedName("id")
    val id: String,

    @SerializedName("username")
    val username: String,

    @SerializedName("rol")
    val rol: String? // Campo nuevo: 'admin', 'tecnico', 'cliente'
)
