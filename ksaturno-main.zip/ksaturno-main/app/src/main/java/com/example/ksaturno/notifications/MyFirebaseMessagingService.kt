package com.example.ksaturno.notifications

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.ksaturno.MainActivity
import com.example.ksaturno.R
import com.example.ksaturno.RetrofitClient
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MyFirebaseMessagingService : FirebaseMessagingService() {

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        // Check if message contains a data payload.
        if (remoteMessage.data.isNotEmpty()) {
            Log.d(TAG, "Message data payload: ${remoteMessage.data}")
            // Handle data payload if needed
        }

        // Check if message contains a notification payload.
        remoteMessage.notification?.let {
            Log.d(TAG, "Message Notification Body: ${it.body}")
            sendNotification(it.title ?: "Notificación", it.body ?: "")
        }
    }

    override fun onNewToken(token: String) {
        Log.d(TAG, "Refreshed token: $token")

        // If you want to send messages to this application instance or
        // manage this apps subscriptions on the server side, send the
        // FCM registration token to your app server.
        sendRegistrationToServer(token)
    }

    private fun sendRegistrationToServer(token: String) {
        // Aquí deberías obtener el ID del usuario actual (ej. de SharedPreferences)
        // Por ahora pondremos un ID temporal o 0 si no hay usuario logueado
        val userId = getUserIdFromPreferences() 

        if (userId != -1) {
            val request = UpdateFcmTokenRequest(userId, token)
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val response = RetrofitClient.instance.updateFcmToken(request)
                    if (response.isSuccessful) {
                        Log.d(TAG, "Token sent to server successfully")
                    } else {
                        Log.e(TAG, "Failed to send token to server: ${response.code()}")
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Error sending token to server", e)
                }
            }
        }
    }
    
    private fun getUserIdFromPreferences(): Int {
        // TODO: Implementa esto según cómo guardes la sesión del usuario
        // Ejemplo:
        // val sharedPref = getSharedPreferences("user_session", Context.MODE_PRIVATE)
        // return sharedPref.getInt("user_id", -1)
        return 1 // Placeholder: Cambia esto por tu lógica real de usuario
    }

    private fun sendNotification(title: String, messageBody: String) {
        val intent = Intent(this, MainActivity::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val pendingIntent = PendingIntent.getActivity(
            this, 0 /* Request code */, intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_ONE_SHOT
        )

        val channelId = getString(R.string.default_notification_channel_id)
        val defaultSoundUri = android.media.RingtoneManager.getDefaultUri(android.media.RingtoneManager.TYPE_NOTIFICATION)
        val notificationBuilder = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(R.drawable.ic_notification) // Asegúrate de tener este icono o cambia a uno existente como R.drawable.ic_menu_camera
            .setContentTitle(title)
            .setContentText(messageBody)
            .setAutoCancel(true)
            .setSound(defaultSoundUri)
            .setContentIntent(pendingIntent)

        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        // Since android Oreo notification channel is needed.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Channel human readable title",
                NotificationManager.IMPORTANCE_DEFAULT
            )
            notificationManager.createNotificationChannel(channel)
        }

        notificationManager.notify(0 /* ID of notification */, notificationBuilder.build())
    }

    companion object {
        private const val TAG = "MyFirebaseMsgService"
    }
}
