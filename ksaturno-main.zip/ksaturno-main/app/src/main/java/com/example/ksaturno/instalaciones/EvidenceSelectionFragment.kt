package com.example.ksaturno.instalaciones

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.ksaturno.R
import com.example.ksaturno.databinding.FragmentEvidenceSelectionBinding

class EvidenceSelectionFragment : Fragment() {

    private var _binding: FragmentEvidenceSelectionBinding? = null
    private val binding get() = _binding!!
    private lateinit var viewModel: InstalacionesViewModel
    private lateinit var adapter: EvidenceSelectionAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentEvidenceSelectionBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        viewModel = ViewModelProvider(this).get(InstalacionesViewModel::class.java)

        val sharedPref = requireActivity().getSharedPreferences("UserSession", Context.MODE_PRIVATE)
        val userId = sharedPref.getInt("USER_ID", -1)
        
        // Always load technician pending tasks here
        viewModel.fetchInstalaciones("tecnico", userId)

        adapter = EvidenceSelectionAdapter(emptyList()) { instalacion ->
            // Navigate to Evidence Upload Fragment with the selected installation ID
            val bundle = Bundle().apply {
                putInt("installationId", instalacion.idInstalacion)
            }
            // We use the action ID or the fragment ID directly if possible
            // Assuming we added an ID "evidence_upload" in nav_graph that points to InstallationEvidenceFragment
            // BUT, we are already IN "evidence_upload" destination if we navigated here via menu... wait.
            
            // CORRECTION: The menu item "evidence_upload" (R.id.evidence_upload) points to THIS fragment now.
            // We need to navigate to the ACTUAL evidence upload screen, which is InstallationEvidenceFragment.
            // In nav_graph, let's assume we need an action from here to there.
            // Or we can use the destination ID R.id.instalacionPaso3EvidenceFragment
            
            findNavController().navigate(R.id.instalacionPaso3EvidenceFragment, bundle)
        }

        binding.rvEvidenceSelection.layoutManager = LinearLayoutManager(context)
        binding.rvEvidenceSelection.adapter = adapter

        viewModel.instalacionesDisplay.observe(viewLifecycleOwner) { list ->
            adapter.updateData(list)
            binding.tvEmptyState.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
            binding.rvEvidenceSelection.visibility = if (list.isNotEmpty()) View.VISIBLE else View.GONE
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
