package com.example.ksaturno

import android.util.Log
import com.google.gson.GsonBuilder
import okhttp3.OkHttpClient
import okhttp3.ResponseBody
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object RetrofitClient {
    // private const val BASE_URL = "http://10.0.2.2/saturno/" 
    private const val BASE_URL = "http://192.168.0.105/saturno/"
    // private const val BASE_URL = "http://saturnologintech.selfip.com/saturno/"

    val instance: ApiService by lazy {
        
        // Interceptor para ver la respuesta "cruda" del servidor en el Logcat
        val loggingInterceptor = okhttp3.Interceptor { chain ->
            val request = chain.request()
            val response = chain.proceed(request)
            
            val responseBody = response.body
            val content = responseBody?.string() ?: ""
            
            // Imprimir en Logcat
            Log.d("API_DEBUG", "URL: ${request.url}")
            Log.d("API_DEBUG", "Code: ${response.code}")
            Log.d("API_DEBUG", "Raw Body: $content")
            
            // Reconstruir la respuesta porque el body solo se puede leer una vez
            val newBody = ResponseBody.create(responseBody?.contentType(), content)
            response.newBuilder().body(newBody).build()
        }

        val client = OkHttpClient.Builder()
            .addInterceptor(loggingInterceptor)
            .build()

        val gson = GsonBuilder()
            .setLenient()
            .create()
            
        val retrofit = Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(client) // Usar el cliente con logs
            .addConverterFactory(GsonConverterFactory.create(gson))
            .build()
            
        retrofit.create(ApiService::class.java)
    }
}
