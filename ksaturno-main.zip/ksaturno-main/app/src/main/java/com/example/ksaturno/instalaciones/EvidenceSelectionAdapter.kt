package com.example.ksaturno.instalaciones

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.ksaturno.R

class EvidenceSelectionAdapter(
    private var instalaciones: List<InstalacionDisplay>,
    private val onItemClick: (InstalacionDisplay) -> Unit
) : RecyclerView.Adapter<EvidenceSelectionAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_instalacion_simple, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val instalacion = instalaciones[position]
        holder.bind(instalacion)
        holder.itemView.setOnClickListener { onItemClick(instalacion) }
    }

    override fun getItemCount(): Int = instalaciones.size

    fun updateData(newInstalaciones: List<InstalacionDisplay>) {
        instalaciones = newInstalaciones
        notifyDataSetChanged()
    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val unidadTextView: TextView = itemView.findViewById(R.id.tv_unidad_nombre_simple)
        private val fechaTextView: TextView = itemView.findViewById(R.id.tv_fecha_instalacion_simple)

        fun bind(instalacion: InstalacionDisplay) {
            unidadTextView.text = "Unidad: ${instalacion.nombreUnidad}"
            fechaTextView.text = "Fecha: ${instalacion.fechaInstalacion}"
        }
    }
}
