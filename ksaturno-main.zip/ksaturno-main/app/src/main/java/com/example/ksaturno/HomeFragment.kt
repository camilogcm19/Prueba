package com.example.ksaturno

import android.content.Context
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.ksaturno.databinding.FragmentHomeBinding
import com.example.ksaturno.home.HomeViewModel
import com.example.ksaturno.home.RenewalAlertAdapter
import com.example.ksaturno.instalaciones.InstalacionesAdapter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!
    private lateinit var viewModel: HomeViewModel
    
    // Adapters are initialized here to avoid scoping issues
    private var renewalAdapter: RenewalAlertAdapter? = null
    private var technicianTasksAdapter: InstalacionesAdapter? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        viewModel = ViewModelProvider(this).get(HomeViewModel::class.java)

        val sharedPref = requireActivity().getSharedPreferences("UserSession", Context.MODE_PRIVATE)
        val userRole = sharedPref.getString("USER_ROLE", "admin") ?: "admin"
        val userId = sharedPref.getInt("USER_ID", -1)

        setupViews(userRole)
        setupObservers(userRole)
        
        Log.d("HomeFragment", "Loading data for role: $userRole, ID: $userId")
        viewModel.loadDashboardData(userRole, userId)
    }

    private fun setupViews(userRole: String) {
        binding.tvCurrentDate.text = SimpleDateFormat("dd 'de' MMMM, yyyy", Locale.getDefault()).format(Date())

        if (userRole.equals("tecnico", ignoreCase = true)) {
            binding.layoutAdminDashboard.visibility = View.GONE
            binding.layoutTechnicianDashboard.visibility = View.VISIBLE
            
            technicianTasksAdapter = InstalacionesAdapter(
                emptyList(),
                userRole,
                onEditClick = { instalacion ->
                    val bundle = Bundle().apply {
                        putInt("installationId", instalacion.idInstalacion)
                    }
                    try {
                        findNavController().navigate(R.id.instalacionPaso1Fragment, bundle)
                    } catch (e: Exception) {
                        Log.e("HomeFragment", "Navigation to edit failed", e)
                    }
                },
                onDeleteClick = {},
                onGenerateInvoiceClick = {}
            )
            
            binding.rvTechnicianTasks.apply {
                adapter = technicianTasksAdapter
                layoutManager = LinearLayoutManager(context)
            }
            
        } else {
            binding.layoutAdminDashboard.visibility = View.VISIBLE
            binding.layoutTechnicianDashboard.visibility = View.GONE
            
            renewalAdapter = RenewalAlertAdapter(emptyList())
            binding.rvRenewalAlerts.adapter = renewalAdapter
        }
    }

    private fun setupObservers(userRole: String) {
        viewModel.isLoading.observe(viewLifecycleOwner) { isLoading ->
            binding.homeProgress.visibility = if (isLoading) View.VISIBLE else View.GONE
        }

        if (userRole.equals("tecnico", ignoreCase = true)) {
            viewModel.technicianTasks.observe(viewLifecycleOwner) { tasks ->
                Log.d("HomeFragment", "Technician tasks received: ${tasks.size} items")
                technicianTasksAdapter?.updateData(tasks)
                binding.tvNoTasks.visibility = if (tasks.isEmpty()) View.VISIBLE else View.GONE
                binding.rvTechnicianTasks.visibility = if (tasks.isNotEmpty()) View.VISIBLE else View.GONE
            }
        } else {
            viewModel.renewalAlerts.observe(viewLifecycleOwner) { alerts ->
                Log.d("HomeFragment", "Admin alerts received: ${alerts.size} items")
                renewalAdapter?.updateData(alerts)
            }

            viewModel.totalRenewals.observe(viewLifecycleOwner) { count ->
                binding.tvTotalRenewals.text = count.toString()
            }

            viewModel.totalAmount.observe(viewLifecycleOwner) { amount ->
                binding.tvTotalAmount.text = String.format("$ %.2f", amount)
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
