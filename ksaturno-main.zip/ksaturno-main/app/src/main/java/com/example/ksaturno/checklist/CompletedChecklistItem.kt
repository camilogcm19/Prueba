package com.example.ksaturno.checklist

import com.google.gson.annotations.SerializedName

/**
 * Represents a checklist item that is pending evidence.
 * This model matches the JSON from 'evidencias_pendientes.php'
 */
data class CompletedChecklistItem(
    // The PHP script returns the ID aliased as 'id'
    @SerializedName("id") val idListaVerificacion: Int,
    
    // The PHP script returns the description aliased as 'nombre_item'
    @SerializedName("nombre_item") val descripcion: String
)
