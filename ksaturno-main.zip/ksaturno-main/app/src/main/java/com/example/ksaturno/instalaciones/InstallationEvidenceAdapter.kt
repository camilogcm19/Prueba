package com.example.ksaturno.instalaciones

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.ksaturno.R
import com.example.ksaturno.checklist.CompletedChecklistItem

class InstallationEvidenceAdapter(
    private var items: List<CompletedChecklistItem>,
    private val listener: EvidenceItemListener
) : RecyclerView.Adapter<InstallationEvidenceAdapter.ViewHolder>() {

    interface EvidenceItemListener {
        fun onTakePhotoClick(item: CompletedChecklistItem)
        fun onSelectGalleryClick(item: CompletedChecklistItem) // New listener method
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_installation_evidence, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(items[position], listener)
    }

    override fun getItemCount(): Int = items.size

    fun updateItems(newItems: List<CompletedChecklistItem>) {
        items = newItems
        notifyDataSetChanged()
    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val description: TextView = itemView.findViewById(R.id.tv_evidence_item_description)
        private val cameraButton: ImageButton = itemView.findViewById(R.id.btn_take_photo)
        private val galleryButton: ImageButton = itemView.findViewById(R.id.btn_select_gallery)

        fun bind(item: CompletedChecklistItem, listener: EvidenceItemListener) {
            description.text = item.descripcion
            cameraButton.setOnClickListener { listener.onTakePhotoClick(item) }
            galleryButton.setOnClickListener { listener.onSelectGalleryClick(item) }
        }
    }
}
