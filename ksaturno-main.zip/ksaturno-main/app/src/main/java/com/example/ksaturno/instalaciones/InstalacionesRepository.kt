package com.example.ksaturno.instalaciones

import com.example.ksaturno.ApiService
import com.example.ksaturno.ApiResponse
import com.example.ksaturno.empresa.Empresa
import com.example.ksaturno.facturas.GenerateInvoiceRequest
import com.google.gson.Gson
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class InstalacionesRepository(private val apiService: ApiService) {

    suspend fun getInstalaciones(): List<Instalacion> {
        return withContext(Dispatchers.IO) {
            val response = apiService.getInstalaciones()
            if (response.isSuccessful) {
                response.body() ?: emptyList()
            } else {
                throw Exception("Error fetching instalaciones: ${response.code()}")
            }
        }
    }

    suspend fun getInstalacionesDisplay(): List<InstalacionDisplay> {
        return withContext(Dispatchers.IO) {
            val response = apiService.getInstalacionesDisplay()
            if (response.isSuccessful) {
                response.body() ?: emptyList()
            } else {
                throw Exception("Error fetching instalaciones display: ${response.code()}")
            }
        }
    }
    
    // New method for technicians
    suspend fun getInstalacionesPendientesTecnico(userId: Int): List<InstalacionDisplay> {
        return withContext(Dispatchers.IO) {
            val response = apiService.getInstalacionesPendientesTecnico(userId)
            if (response.isSuccessful) {
                response.body() ?: emptyList()
            } else {
                throw Exception("Error fetching technician tasks: ${response.code()}")
            }
        }
    }

    suspend fun createInstalacion(request: CreateInstalacionRequest): ApiResponse {
        return withContext(Dispatchers.IO) {
            val response = apiService.createInstalacion(request)
            if (response.isSuccessful && response.body() != null) {
                response.body()!!
            } else {
                ApiResponse(false, "Error de red: ${response.code()}", null)
            }
        }
    }
    
    suspend fun updateInstalacion(id: Int, instalacion: Instalacion): ApiResponse {
        return withContext(Dispatchers.IO) {
            try {
                val response = apiService.updateInstalacion(id, instalacion)
                if (response.isSuccessful && response.body() != null) {
                    response.body()!!
                } else {
                    ApiResponse(false, "Error de red al actualizar: ${response.code()}", null)
                }
            } catch (e: Exception) {
                ApiResponse(false, "Excepción al actualizar: ${e.message}", null)
            }
        }
    }

    suspend fun getInstalacionById(id: Int): Instalacion {
        return withContext(Dispatchers.IO) {
            // Intentamos primero con el endpoint específico
            val response = try {
                apiService.getInstalacionById(id)
            } catch (e: Exception) {
                null
            }

            if (response != null && response.isSuccessful && response.body() != null) {
                return@withContext response.body()!!
            }

            // Fallback: Si falla el endpoint específico (ej. error 400 o 404),
            // buscamos en la lista completa de instalaciones.
            // Esto asegura que la app funcione incluso si el script individual falla.
            try {
                val allInstalaciones = getInstalaciones()
                val found = allInstalaciones.find { it.idInstalacion == id }
                found ?: throw Exception("Instalación no encontrada con ID: $id (API Code: ${response?.code()})")
            } catch (e: Exception) {
                // Si también falla obtener la lista, lanzamos el error original o el de la lista
                throw Exception("Error al cargar detalles: ${e.message}")
            }
        }
    }

    suspend fun deleteInstalacion(id: Int): ApiResponse {
        return withContext(Dispatchers.IO) {
            try {
                val response = apiService.deleteInstalacion(InstalacionIdBody(id))
                if (response.isSuccessful && response.body() != null) {
                    response.body()!!
                } else {
                    ApiResponse(false, "Error de red: ${response.code()}", null)
                }
            } catch (e: Exception) {
                ApiResponse(false, "Excepción al eliminar: ${e.message}", null)
            }
        }
    }

    suspend fun generateInvoice(request: GenerateInvoiceRequest): ApiResponse {
        return withContext(Dispatchers.IO) {
            try {
                val response = apiService.generateInvoiceFromInstallation(request)
                if (response.isSuccessful && response.body() != null) {
                    response.body()!!
                } else {
                    ApiResponse(false, "Error de red: ${response.code()}", null)
                }
            } catch (e: Exception) {
                ApiResponse(false, "Excepción al generar factura: ${e.message}", null)
            }
        }
    }

    // Helper to get companies for selection dialog
    suspend fun getEmpresas(): List<Empresa> {
        return withContext(Dispatchers.IO) {
            val response = apiService.getEmpresas()
            if (response.isSuccessful) {
                response.body() ?: emptyList()
            } else {
                emptyList()
            }
        }
    }
}
