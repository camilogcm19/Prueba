package com.example.ksaturno.instalaciones

import android.net.Uri
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.ksaturno.RetrofitClient
import com.example.ksaturno.checklist.CompletedChecklistItem
import com.example.ksaturno.evidencias.CreateEvidenciaRequest
import com.example.ksaturno.evidencias.EvidenceRepository
import kotlinx.coroutines.launch
import java.io.File

class InstallationEvidenceViewModel(private val installationId: Int) : ViewModel() {

    private val repository = EvidenceRepository(RetrofitClient.instance)

    private val _evidencePendingItems = MutableLiveData<List<CompletedChecklistItem>>()
    val evidencePendingItems: LiveData<List<CompletedChecklistItem>> = _evidencePendingItems

    private val _error = MutableLiveData<String>()
    val error: LiveData<String> = _error

    private val _saveSuccess = MutableLiveData<Boolean>()
    val saveSuccess: LiveData<Boolean> = _saveSuccess

    init {
        fetchEvidencePendingItems()
    }

    fun fetchEvidencePendingItems() {
        viewModelScope.launch {
            try {
                _evidencePendingItems.value = repository.getEvidencePendingItems(installationId)
            } catch (e: Exception) {
                _error.value = e.message
            }
        }
    }

    // CORRECTED: This now accepts a File object directly
    fun saveEvidence(idListaVerificacion: Int, imageFile: File, description: String?) {
        viewModelScope.launch {
            try {
                if (!imageFile.exists()) {
                    _error.value = "El archivo de imagen no existe o no se pudo leer."
                    return@launch
                }

                // 2. Upload Image to Server
                val uploadResponse = repository.uploadImage(imageFile)
                
                if (uploadResponse.success && uploadResponse.path != null) {
                    // 3. Save Evidence Record with server path
                    val request = CreateEvidenciaRequest(
                        idListaVerificacion = idListaVerificacion,
                        rutaArchivo = uploadResponse.path, // Use server path
                        descripcion = description
                    )

                    val saveResponse = repository.saveEvidence(request)
                    if (saveResponse.success) {
                        _saveSuccess.value = true
                    } else {
                        _error.value = saveResponse.message ?: "Error al guardar el registro de evidencia."
                    }
                } else {
                    _error.value = uploadResponse.message // Error from upload
                }

            } catch (e: Exception) {
                _error.value = "Excepción: ${e.message}"
            }
        }
    }

    fun onSaveHandled() {
        _saveSuccess.value = false
    }
}

class InstallationEvidenceViewModelFactory(private val installationId: Int) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(InstallationEvidenceViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return InstallationEvidenceViewModel(installationId) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
