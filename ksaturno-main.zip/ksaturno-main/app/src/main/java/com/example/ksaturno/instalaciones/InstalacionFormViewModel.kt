package com.example.ksaturno.instalaciones

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.ksaturno.RetrofitClient
import com.example.ksaturno.clients.Client
import com.example.ksaturno.clients.ClientsRepository
import com.example.ksaturno.servicios.Servicio
import com.example.ksaturno.servicios.ServiciosRepository
import com.example.ksaturno.technicians.Technician
import com.example.ksaturno.technicians.TechniciansRepository
import com.example.ksaturno.units.UnitsRepository
import com.example.ksaturno.units.Unit as SaturnoUnit
import kotlinx.coroutines.launch

class InstalacionFormViewModel : ViewModel() {

    private val repository = InstalacionesRepository(RetrofitClient.instance)
    private val serviciosRepository = ServiciosRepository(RetrofitClient.instance)
    private val techniciansRepository = TechniciansRepository(RetrofitClient.instance)
    private val unitsRepository = UnitsRepository(RetrofitClient.instance)
    private val clientsRepository = ClientsRepository(RetrofitClient.instance)
    private val apiService = RetrofitClient.instance

    private val _servicios = MutableLiveData<List<Servicio>>()
    val servicios: LiveData<List<Servicio>> = _servicios

    private val _tecnicos = MutableLiveData<List<Technician>>()
    val tecnicos: LiveData<List<Technician>> = _tecnicos

    private val _selectedClient = MutableLiveData<Client?>()
    val selectedClient: LiveData<Client?> = _selectedClient

    private val _unitName = MutableLiveData<String>()
    val unitName: LiveData<String> = _unitName

    private val _installationToEdit = MutableLiveData<Instalacion?>()
    val installationToEdit: LiveData<Instalacion?> = _installationToEdit

    private val _updateResult = MutableLiveData<Boolean>()
    val updateResult: LiveData<Boolean> = _updateResult

    private val _newInstallationId = MutableLiveData<Int?>()
    val newInstallationId: LiveData<Int?> = _newInstallationId

    private val _error = MutableLiveData<String>()
    val error: LiveData<String> = _error

    private var loadedUnits: List<SaturnoUnit> = emptyList()
    
    private var _selectedServiceId: Int? = null
    fun getSavedServiceId(): Int? = _selectedServiceId

    fun fetchSpinnerData() {
        viewModelScope.launch {
            try {
                if (_tecnicos.value.isNullOrEmpty()) {
                    _tecnicos.postValue(techniciansRepository.getTechnicians())
                }
                if (_selectedClient.value == null) {
                    _servicios.postValue(emptyList()) 
                }
            } catch (e: Exception) {
                val errorMsg = "Error al cargar datos iniciales: ${e.message}"
                _error.postValue(errorMsg)
                Log.e("InstalacionFormVM", errorMsg, e)
            }
        }
    }

    fun processClientSearchResult(clientId: Int, clientName: String?) {
        val client = Client(clientId, clientName, null, null, null, null) 
        _selectedClient.value = client
        loadDataForClient(clientId)
    }

    private fun loadDataForClient(clientId: Int) {
        viewModelScope.launch {
            try {
                val clientServices = serviciosRepository.getServiciosByClient(clientId)
                _servicios.postValue(clientServices)
                loadedUnits = unitsRepository.getUnitsByClient(clientId)
            } catch (e: Exception) {
                val errorMsg = "Error al cargar datos del cliente: ${e.message}"
                _error.postValue(errorMsg)
                Log.e("InstalacionFormVM", errorMsg, e)
            }
        }
    }

    fun onServiceSelected(servicio: Servicio) {
        val unit = loadedUnits.find { it.idUnidad == servicio.idUnidad }
        _unitName.value = unit?.nombreUnidad ?: "Unidad desconocida"
        _selectedServiceId = servicio.idServicio
    }

    fun createInstalacion(request: CreateInstalacionRequest) {
        viewModelScope.launch {
            try {
                val response = repository.createInstalacion(request)
                if (response.success && response.newId != null) {
                    _newInstallationId.postValue(response.newId)
                    launch {
                        try {
                            apiService.notifyTechnician(InstalacionIdBody(response.newId))
                        } catch (e: Exception) {
                            Log.e("Notif", "Error avisando al técnico: ${e.message}")
                        }
                    }
                } else {
                    _error.postValue(response.message ?: "Error al crear la instalación, no se recibió ID.")
                }
            } catch (e: Exception) {
                val errorMsg = "Excepción al crear instalación: ${e.message}"
                _error.postValue(errorMsg)
                Log.e("InstalacionFormVM", errorMsg, e)
            }
        }
    }

    fun updateInstalacion(instalacion: Instalacion) {
        viewModelScope.launch {
            try {
                val response = repository.updateInstalacion(instalacion.idInstalacion, instalacion)
                if (response.success) {
                    _updateResult.postValue(true)
                } else {
                    _error.postValue(response.message ?: "Error al actualizar instalación")
                }
            } catch (e: Exception) {
                val errorMsg = "Excepción al actualizar: ${e.message}"
                _error.postValue(errorMsg)
            }
        }
    }

    fun loadInstallationDetails(id: Int) {
        viewModelScope.launch {
            try {
                val instalacion = repository.getInstalacionById(id)
                _installationToEdit.postValue(instalacion)

                val servicios = serviciosRepository.getServicios()
                val servicio = servicios.find { it.idServicio == instalacion.idServicio }
                
                if (servicio != null) {
                     val unidades = unitsRepository.getUnits()
                     val unidad = unidades.find { it.idUnidad == servicio.idUnidad }
                     if (unidad != null) {
                         // Cargar datos de la unidad y el cliente
                         _unitName.postValue(unidad.nombreUnidad ?: "Unidad no encontrada")
                         onInstallationLoadedForEditing(unidad.idCliente, instalacion.idServicio)
                     }
                }

            } catch (e: Exception) {
                _error.postValue("Error al cargar detalles de la instalación: ${e.message}")
            }
        }
    }

    fun onInstallationLoadedForEditing(clientId: Int, serviceId: Int) {
        viewModelScope.launch {
            try {
                val client = clientsRepository.getClientById(clientId)
                _selectedClient.postValue(client)
                loadDataForClient(clientId)
                _selectedServiceId = serviceId
            } catch (e: Exception) {
                _error.postValue("Error al cargar cliente para edición: ${e.message}")
            }
        }
    }

    fun onNavigationComplete() {
        _newInstallationId.value = null
    }
    
    fun clearSelection() {
        _selectedClient.value = null
        _servicios.value = emptyList()
        loadedUnits = emptyList()
        _unitName.value = ""
        _selectedServiceId = null
        _installationToEdit.value = null
    }
}
