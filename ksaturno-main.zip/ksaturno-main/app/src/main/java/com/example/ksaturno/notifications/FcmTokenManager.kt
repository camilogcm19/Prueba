package com.example.ksaturno.notifications

import android.content.Context
import android.util.Log
import com.example.ksaturno.RetrofitClient
import com.google.firebase.messaging.FirebaseMessaging
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

object FcmTokenManager {
    private const val TAG = "FcmTokenManager"

    fun updateTokenOnServer(context: Context, userId: Int) {
        FirebaseMessaging.getInstance().token.addOnCompleteListener { task ->
            if (!task.isSuccessful) {
                Log.w(TAG, "Fetching FCM registration token failed", task.exception)
                return@addOnCompleteListener
            }

            // Get new FCM registration token
            val token = task.result

            Log.d(TAG, "FCM Token obtained: $token")

            // Send to server
            sendRegistrationToServer(userId, token)
        }
    }

    private fun sendRegistrationToServer(userId: Int, token: String) {
        val request = UpdateFcmTokenRequest(userId, token)
        Log.d(TAG, "Sending token to server for user $userId: $request")
        
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val response = RetrofitClient.instance.updateFcmToken(request)
                if (response.isSuccessful) {
                    Log.d(TAG, "Token updated on server successfully. Response: ${response.body()}")
                } else {
                    val errorBody = response.errorBody()?.string()
                    Log.e(TAG, "Failed to update token on server: ${response.code()} - $errorBody")
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error updating token on server", e)
            }
        }
    }
}
